const words = [
  {
    spanish: "manzana",
    english: "apple",
    sentence: "Me gusta comer una manzana cada mañana.",
  },
  {
    spanish: "libro",
    english: "book",
    sentence: "Estoy leyendo un libro interesante.",
  },
  {
    spanish: "perro",
    english: "dog",
    sentence: "El perro está durmiendo en el sofá.",
  },
];
