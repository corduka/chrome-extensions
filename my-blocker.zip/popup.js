chrome.storage.local.get("ruleIdCounter", data => {
  if (typeof data.ruleIdCounter === "number") {
    ruleIdCounter = data.ruleIdCounter;
  } else {
    chrome.storage.local.set({ ruleIdCounter });
  }
});



const addBtn = document.getElementById("addBtn");
const websiteInput = document.getElementById("website");
const list = document.getElementById("list");

let ruleIdCounter = 1000;

function updateUI() {
  chrome.storage.local.get("blockedSites", data => {
    const sites = data.blockedSites || [];
    list.innerHTML = "";

    sites.forEach(site => {
      const li = document.createElement("li");

      const siteText = document.createElement("span");
      siteText.textContent = site;

      const removeBtn = document.createElement("button");
      removeBtn.textContent = "Remove";
      removeBtn.title = "Remove";
      removeBtn.classList.add("remove-btn");

      removeBtn.addEventListener("click", () => {
        chrome.declarativeNetRequest.getDynamicRules(rules => {
          const rule = rules.find(r => r.condition.urlFilter === site);
          if (rule) {
            chrome.declarativeNetRequest.updateDynamicRules({
              removeRuleIds: [rule.id],
            });
          }

          const updatedSites = sites.filter(s => s !== site);
          chrome.storage.local.set({ blockedSites: updatedSites }, updateUI);
        });
      });

      li.appendChild(siteText);
      li.appendChild(removeBtn);
      list.appendChild(li);
    });
  });
}

addBtn.addEventListener("click", () => {
  const site = websiteInput.value.trim();
  if (!site) return;

  chrome.storage.local.get("blockedSites", async data => {
    const blockedSites = data.blockedSites || [];
    if (blockedSites.includes(site)) return;

    const rule = {
      id: ruleIdCounter++,
      priority: 1,
      action: { type: "block" },
      condition: {
        urlFilter: site,
        resourceTypes: ["main_frame"]
      }
    };

    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [rule],
      removeRuleIds: []
    });

    blockedSites.push(site);
    chrome.storage.local.set({ blockedSites });
    updateUI();
    websiteInput.value = "";
  });
});

updateUI();

